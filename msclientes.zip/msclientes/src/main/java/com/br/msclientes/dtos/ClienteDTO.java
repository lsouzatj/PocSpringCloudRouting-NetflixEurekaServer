package com.br.msclientes.dtos;

import lombok.Data;

@Data
public class ClienteDTO {

    private String nome;
    private String cpf;
    private Integer idade;
}
